﻿using System;
using System.Windows;
using $safeprojectname$.ViewModel;

namespace $safeprojectname$
{
    public partial class App : Application
    {
        public App()
        {
            Startup += this.ApplicationStartup;
            Exit += ApplicationExit;
            UnhandledException += this.ApplicationUnhandledException;

            InitializeComponent();
        }

        private void ApplicationStartup(object sender, StartupEventArgs e)
        {
        }

        private static void ApplicationExit(object sender, EventArgs e)
        {
            ViewModelLocator.Cleanup();
        }

        private void ApplicationUnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
        {
            if (System.Diagnostics.Debugger.IsAttached)
            {
                // An unhandled exception has occurred, break in the debugger
                System.Diagnostics.Debugger.Break();
            }
        }
    }
}
